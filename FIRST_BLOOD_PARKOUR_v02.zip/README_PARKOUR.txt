FIRST BLOOD 0.2 - PARKOUR
NEW MOBILE CONTROLS: SPRINT (hold), JUMP, SLIDE (camera duck and speed boost), VAULT (assisted jump in front of crate).
Keyboard: Shift hold to sprint, Space jump, C slide, E vault.
Vault is an assisted jump, not a full ledge-climbing animation.
NOTE: Collision capsule stays full height during slide; no crawling under gaps.
Signed IPA not yet verified.
