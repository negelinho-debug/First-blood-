extends Node3D

# FIRST BLOOD 0.1 — original, self-contained Godot 4 mobile-friendly fighting demo.
# Main menu / duel arena / controls / enemies are generated at runtime.

const ARENA := 10.5
const SPEED := 5.2
const SPRINT_SPEED := 8.2
const JUMP_IMPULSE := 7.4
const SLIDE_DURATION := 0.67
const MAX_HEALTH := 100.0
const TOUCH_SENSITIVITY := 0.0037

var player: CharacterBody3D
var cam: Camera3D
var left_arm: Node3D
var right_arm: Node3D
var enemies: Array = []
var particles: Array = []
var health := MAX_HEALTH
var stamina := 100.0
var score := 0
var combo := 0
var wave := 0
var ended := false
var blocking := false
var punch_cooldown := 0.0
var punch_anim := 0.0
var punch_side := 0
var dash_cooldown := 0.0
var dodge_timer := 0.0
var hurt_flash := 0.0
var round_timer := 0.0
var wave_pause := 1.2
var player_yaw := 0.0
var player_pitch := 0.0
var joystick_touch := -1
var look_touch := -1
var joystick_origin := Vector2.ZERO
var joystick_axis := Vector2.ZERO
var mouse_look := false
var sprinting := false
var slide_timer := 0.0
var slide_cooldown := 0.0
var vault_cooldown := 0.0
var slide_vector := Vector3.ZERO
var player_collider: CollisionShape3D
var base_camera_height := 1.59
var ui: Control
var hud_left: Label
var hud_right: Label
var banner: Label
var end_screen: Panel
var end_label: Label
var tint: ColorRect
var move_circle: Panel
var move_dot: Panel
var btn_attack: Button
var btn_block: Button
var btn_dodge: Button
var btn_kick: Button
var btn_sprint: Button
var btn_jump: Button
var btn_slide: Button
var btn_vault: Button
var snd_punch: AudioStreamPlayer
var snd_hit: AudioStreamPlayer
var snd_damage: AudioStreamPlayer
var snd_music: AudioStreamPlayer

func _ready() -> void:
    randomize()
    _create_environment()
    _create_level()
    _create_player()
    _create_ui()
    _create_audio()
    get_viewport().size_changed.connect(_layout_ui)
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    _announce("FIRST BLOOD  /  NIGHTSHIFT", 2.8)
    _layout_ui()

func _material(color: Color, emission: bool = false, metal: float = 0.0) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.metallic = metal
    m.roughness = 0.48
    if emission:
        m.emission_enabled = true
        m.emission = color
        m.emission_energy_multiplier = 2.4
    return m

func _box(parent: Node3D, pos: Vector3, size: Vector3, color: Color, emission := false, metal := 0.0) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    mi.mesh = mesh
    mi.material_override = _material(color, emission, metal)
    mi.position = pos
    parent.add_child(mi)
    return mi

func _sphere(parent: Node3D, pos: Vector3, radius: float, color: Color, emission := false) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    mesh.radial_segments = 10
    mesh.rings = 6
    mi.mesh = mesh
    mi.material_override = _material(color, emission)
    mi.position = pos
    parent.add_child(mi)
    return mi

func _static_box(pos: Vector3, size: Vector3, color: Color, emission := false) -> void:
    _box(self, pos, size, color, emission, 0.3)
    var body := StaticBody3D.new()
    body.position = pos
    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = size
    collision.shape = shape
    body.add_child(collision)
    add_child(body)

func _neon(pos: Vector3, color: Color, length: float, horizontal := true) -> void:
    var size := Vector3(length, 0.09, 0.11) if horizontal else Vector3(0.10, length, 0.11)
    _box(self, pos, size, color, true)
    var light := OmniLight3D.new()
    light.position = pos + Vector3(0, 0, 0.35)
    light.light_color = color
    light.light_energy = 1.3
    light.omni_range = 8.0
    light.shadow_enabled = false
    add_child(light)

func _create_environment() -> void:
    var we := WorldEnvironment.new()
    var e := Environment.new()
    e.background_mode = Environment.BG_COLOR
    e.background_color = Color("0c101b")
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color("7582a3")
    e.ambient_light_energy = 0.48
    e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    we.environment = e
    add_child(we)
    var moon := DirectionalLight3D.new()
    moon.rotation_degrees = Vector3(-50, -40, 0)
    moon.light_color = Color("7f9cff")
    moon.light_energy = 0.42
    moon.shadow_enabled = false
    add_child(moon)

func _create_level() -> void:
    # Floors/walls use real collisions. Everything else is a handmade modular environment.
    _static_box(Vector3(0, -0.28, 0), Vector3(24, 0.55, 24), Color("1d2230"))
    _static_box(Vector3(0, 3.2, -11.6), Vector3(24, 6.4, 0.8), Color("1b2233"))
    _static_box(Vector3(0, 3.2, 11.6), Vector3(24, 6.4, 0.8), Color("151b29"))
    _static_box(Vector3(-11.6, 3.2, 0), Vector3(0.8, 6.4, 24), Color("192337"))
    _static_box(Vector3(11.6, 3.2, 0), Vector3(0.8, 6.4, 24), Color("211e31"))
    _box(self, Vector3(0, 6.3, 0), Vector3(24, 0.2, 24), Color("141a2b"))
    for i in range(-10, 11, 2):
        _box(self, Vector3(float(i), 0.014, 0), Vector3(0.025, 0.02, 22), Color("343b52"))
        _box(self, Vector3(0, 0.016, float(i)), Vector3(22, 0.02, 0.025), Color("343b52"))
    for x in [-9.4, 9.4]:
        for z in [-9.4, 9.4]:
            _box(self, Vector3(x, 2.8, z), Vector3(0.75, 5.6, 0.75), Color("323343"), false, 0.65)
            _box(self, Vector3(x, 4.7, z), Vector3(0.8, 0.12, 0.82), Color("00d9ff"), true)
    for x in [-7.0, 0.0, 7.0]:
        _neon(Vector3(x, 5.55, -11.1), Color("fe2c65"), 3.4)
        _neon(Vector3(x, 5.55, 11.1), Color("06e5ed"), 3.4)
    for z in [-6.0, 0.0, 6.0]:
        _neon(Vector3(-11.1, 4.2, z), Color("ff367c"), 2.4, false)
        _neon(Vector3(11.1, 4.2, z), Color("00dbff"), 2.4, false)
    for x in [-7.2, 7.2]:
        for z in [-5.4, 3.8]:
            _box(self, Vector3(x, 0.55, z), Vector3(1.9, 1.1, 1.3), Color("45495b"), false, 0.55)
            _box(self, Vector3(x, 1.13, z), Vector3(1.98, 0.07, 1.38), Color("5b667e"))
    # Parkour course: low crates to vault or jump across.
    _static_box(Vector3(-4.0, 0.52, 4.0), Vector3(1.5, 1.04, 1.6), Color("34394a"))
    _static_box(Vector3(2.2, 0.45, 2.3), Vector3(1.45, 0.90, 1.4), Color("35394b"))
    _static_box(Vector3(5.6, 0.56, -0.3), Vector3(1.6, 1.12, 1.25), Color("32394e"))
    for p in [Vector3(-4.0, 1.08, 4.0), Vector3(2.2, 0.95, 2.3), Vector3(5.6, 1.16, -0.3)]:
        _box(self, p, Vector3(1.5, 0.07, 1.4), Color("00c9ed"), true)
    _box(self, Vector3(0, 2.35, -11.1), Vector3(7.5, 3.3, 0.1), Color("29283e"))
    _box(self, Vector3(0, 2.8, -11.02), Vector3(6.5, 0.1, 0.12), Color("ff2b6f"), true)
    _box(self, Vector3(0, 1.9, -11.02), Vector3(3.9, 0.08, 0.12), Color("00d9fb"), true)
    var logo := Label3D.new()
    logo.text = "N I G H T S H I F T"
    logo.font_size = 92
    logo.pixel_size = 0.0029
    logo.modulate = Color("ffedf5")
    logo.outline_modulate = Color("ee296f")
    logo.position = Vector3(0, 3.25, -10.90)
    logo.rotation.y = PI
    add_child(logo)

func _create_player() -> void:
    player = CharacterBody3D.new()
    player.name = "Player"
    player.position = Vector3(0, 0.06, 7.4)
    var collider := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.34
    cap.height = 1.75
    collider.position.y = 0.88
    collider.shape = cap
    player_collider = collider
    player.add_child(collider)
    add_child(player)
    cam = Camera3D.new()
    cam.position = Vector3(0, 1.59, 0)
    cam.current = true
    cam.fov = 86
    player.add_child(cam)
    left_arm = _make_arm(-1)
    right_arm = _make_arm(1)

func _make_arm(side: int) -> Node3D:
    var arm := Node3D.new()
    arm.position = Vector3(float(side) * 0.38, -0.48, -0.72)
    cam.add_child(arm)
    var sleeve := _box(arm, Vector3(0, -0.05, 0.12), Vector3(0.22, 0.23, 0.53), Color("242c3c"))
    sleeve.rotation_degrees.x = -13
    _box(arm, Vector3(0, 0.04, -0.18), Vector3(0.21, 0.20, 0.36), Color("8c4051"))
    _box(arm, Vector3(0, 0.06, -0.39), Vector3(0.24, 0.21, 0.22), Color("242935"), false, 0.4)
    for k in range(3):
        _box(arm, Vector3((k - 1) * 0.065, 0.11, -0.50), Vector3(0.057, 0.10, 0.10), Color("a04456"))
    return arm

func _make_enemy(at: Vector3, is_boss: bool = false) -> void:
    var root := Node3D.new()
    root.position = at
    add_child(root)
    var outfit := Color("5b1d35") if not is_boss else Color("253f63")
    _box(root, Vector3(0, 1.22, 0), Vector3(0.66, 0.88, 0.38), outfit, false, 0.25)
    _box(root, Vector3(0, 1.84, 0), Vector3(0.41, 0.54, 0.40), Color("aa7866"))
    _box(root, Vector3(0, 1.9, -0.22), Vector3(0.48, 0.26, 0.07), Color("131a27"), false, 0.65)
    _box(root, Vector3(-0.18, 0.40, 0), Vector3(0.21, 0.73, 0.29), Color("293140"))
    _box(root, Vector3(0.18, 0.40, 0), Vector3(0.21, 0.73, 0.29), Color("293140"))
    var arm_l := Node3D.new()
    arm_l.position = Vector3(-0.49, 1.55, 0)
    root.add_child(arm_l)
    _box(arm_l, Vector3(0, -0.32, -0.08), Vector3(0.24, 0.76, 0.25), outfit)
    var arm_r := Node3D.new()
    arm_r.position = Vector3(0.49, 1.55, 0)
    root.add_child(arm_r)
    _box(arm_r, Vector3(0, -0.32, -0.08), Vector3(0.24, 0.76, 0.25), outfit)
    var health_bar := _box(root, Vector3(0, 2.35, 0), Vector3(0.76, 0.07, 0.09), Color("ff315e"), true)
    if is_boss:
        root.scale = Vector3.ONE * 1.30
        _sphere(root, Vector3(0, 2.24, 0), 0.12, Color("00f3e9"), true)
    enemies.append({"node": root, "left": arm_l, "right": arm_r, "bar": health_bar,
        "hp": 10.0 if is_boss else 3.0, "max_hp": 10.0 if is_boss else 3.0,
        "boss": is_boss, "speed": 1.4 if is_boss else randf_range(1.8, 2.5),
        "cooldown": randf_range(0.55, 1.1), "stun": 0.0, "alive": true,
        "stride": randf() * 6.0})

func _new_wave() -> void:
    wave += 1
    wave_pause = 1.7
    if wave == 1:
        _announce("ROUND 1 /  THE FLOOR", 2.0)
        _make_enemy(Vector3(-4.0, 0.0, -4.2))
        _make_enemy(Vector3(4.0, 0.0, -4.5))
    elif wave == 2:
        _announce("ROUND 2 /  NO MERCY", 2.0)
        for x in [-4.6, 0.0, 4.6]:
            _make_enemy(Vector3(x, 0.0, -5.7))
    elif wave == 3:
        _announce("FINAL ROUND / THE ENFORCER", 2.5)
        _make_enemy(Vector3(0, 0.0, -6.0), true)
    else:
        _finish(true)

func _create_audio() -> void:
    snd_punch = AudioStreamPlayer.new()
    snd_punch.stream = load("res://assets/punch.wav")
    snd_punch.volume_db = -5
    add_child(snd_punch)
    snd_hit = AudioStreamPlayer.new()
    snd_hit.stream = load("res://assets/hit.wav")
    snd_hit.volume_db = -1
    add_child(snd_hit)
    snd_damage = AudioStreamPlayer.new()
    snd_damage.stream = load("res://assets/hurt.wav")
    snd_damage.volume_db = -6
    add_child(snd_damage)
    snd_music = AudioStreamPlayer.new()
    snd_music.stream = load("res://assets/music.wav")
    snd_music.volume_db = -15
    add_child(snd_music)
    snd_music.play()

func _style_button(button: Button, color: Color) -> void:
    var normal := StyleBoxFlat.new()
    normal.bg_color = color
    normal.border_color = Color("b8cadc")
    normal.set_border_width_all(2)
    normal.set_corner_radius_all(12)
    button.add_theme_stylebox_override("normal", normal)
    var down := normal.duplicate()
    down.bg_color = color.lightened(0.25)
    button.add_theme_stylebox_override("pressed", down)
    button.add_theme_color_override("font_color", Color.WHITE)
    button.add_theme_font_size_override("font_size", 20)
    button.focus_mode = Control.FOCUS_NONE

func _button(text: String, color: Color, on_click: Callable) -> Button:
    var b := Button.new()
    b.text = text
    b.pressed.connect(on_click)
    _style_button(b, color)
    ui.add_child(b)
    return b

func _create_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    ui = Control.new()
    ui.anchor_right = 1
    ui.anchor_bottom = 1
    ui.mouse_filter = Control.MOUSE_FILTER_PASS
    layer.add_child(ui)
    var header := Panel.new()
    header.anchor_right = 1
    header.offset_bottom = 77
    var st := StyleBoxFlat.new()
    st.bg_color = Color(0.035, 0.055, 0.09, 0.77)
    header.add_theme_stylebox_override("panel", st)
    header.mouse_filter = Control.MOUSE_FILTER_IGNORE
    ui.add_child(header)
    hud_left = Label.new()
    hud_left.position = Vector2(22, 12)
    hud_left.add_theme_font_size_override("font_size", 20)
    hud_left.add_theme_color_override("font_color", Color("fce0e9"))
    hud_left.mouse_filter = Control.MOUSE_FILTER_IGNORE
    ui.add_child(hud_left)
    hud_right = Label.new()
    hud_right.add_theme_font_size_override("font_size", 20)
    hud_right.add_theme_color_override("font_color", Color("84edff"))
    hud_right.mouse_filter = Control.MOUSE_FILTER_IGNORE
    ui.add_child(hud_right)
    banner = Label.new()
    banner.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    banner.add_theme_color_override("font_color", Color("ffffff"))
    banner.add_theme_font_size_override("font_size", 32)
    banner.add_theme_color_override("font_shadow_color", Color("d8255e"))
    banner.add_theme_constant_override("shadow_offset_x", 2)
    banner.add_theme_constant_override("shadow_offset_y", 2)
    banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
    ui.add_child(banner)
    var cross := Label.new()
    cross.name = "Crosshair"
    cross.text = "+"
    cross.add_theme_font_size_override("font_size", 28)
    cross.add_theme_color_override("font_color", Color("ffecf1"))
    cross.mouse_filter = Control.MOUSE_FILTER_IGNORE
    ui.add_child(cross)
    move_circle = Panel.new()
    move_circle.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var cs := StyleBoxFlat.new()
    cs.bg_color = Color(0.2, 0.3, 0.4, 0.27)
    cs.border_color = Color(0.4, 0.8, 0.97, 0.6)
    cs.set_border_width_all(3)
    cs.set_corner_radius_all(80)
    move_circle.add_theme_stylebox_override("panel", cs)
    ui.add_child(move_circle)
    move_dot = Panel.new()
    move_dot.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var ds := StyleBoxFlat.new()
    ds.bg_color = Color("19bbd3")
    ds.set_corner_radius_all(80)
    move_dot.add_theme_stylebox_override("panel", ds)
    ui.add_child(move_dot)
    btn_attack = _button("PUNCH", Color("9b2048"), _attack)
    btn_kick = _button("KICK", Color("963e1f"), _kick)
    btn_block = _button("BLOCK", Color("26536b"), func(): pass)
    btn_block.button_down.connect(func(): blocking = true)
    btn_block.button_up.connect(func(): blocking = false)
    btn_dodge = _button("DODGE", Color("235c50"), _dodge)
    btn_sprint = _button("SPRINT", Color("23525e"), func(): pass)
    btn_sprint.button_down.connect(func(): sprinting = true)
    btn_sprint.button_up.connect(func(): sprinting = false)
    btn_jump = _button("JUMP", Color("275a78"), _jump)
    btn_slide = _button("SLIDE", Color("4f376d"), _slide)
    btn_vault = _button("VAULT", Color("246e6a"), _vault)
    tint = ColorRect.new()
    tint.anchor_right = 1
    tint.anchor_bottom = 1
    tint.color = Color(0.9, 0.0, 0.13, 0)
    tint.mouse_filter = Control.MOUSE_FILTER_IGNORE
    ui.add_child(tint)
    end_screen = Panel.new()
    end_screen.visible = false
    var es := StyleBoxFlat.new()
    es.bg_color = Color(0.055, 0.065, 0.12, 0.95)
    es.border_color = Color("ef316c")
    es.set_border_width_all(3)
    es.set_corner_radius_all(18)
    end_screen.add_theme_stylebox_override("panel", es)
    ui.add_child(end_screen)
    end_label = Label.new()
    end_label.position = Vector2(30, 32)
    end_label.add_theme_font_size_override("font_size", 29)
    end_screen.add_child(end_label)
    var again := Button.new()
    again.text = "RESTART"
    again.position = Vector2(130, 210)
    again.size = Vector2(180, 60)
    _style_button(again, Color("ac244f"))
    again.pressed.connect(func(): get_tree().reload_current_scene())
    end_screen.add_child(again)

func _layout_ui() -> void:
    if ui == null:
        return
    var size := get_viewport().get_visible_rect().size
    hud_right.position = Vector2(size.x - 295, 12)
    banner.position = Vector2(size.x * 0.2, 105)
    banner.size = Vector2(size.x * 0.6, 90)
    var cross := ui.get_node("Crosshair") as Label
    cross.position = size * 0.5 - Vector2(9, 23)
    move_circle.position = Vector2(36, size.y - 210)
    move_circle.size = Vector2(152, 152)
    _move_dot()
    btn_attack.position = Vector2(size.x - 155, size.y - 180)
    btn_attack.size = Vector2(135, 79)
    btn_kick.position = Vector2(size.x - 294, size.y - 112)
    btn_kick.size = Vector2(130, 76)
    btn_block.position = Vector2(size.x - 300, size.y - 198)
    btn_block.size = Vector2(128, 70)
    btn_dodge.position = Vector2(size.x - 165, size.y - 90)
    btn_dodge.size = Vector2(137, 69)
    btn_sprint.position = Vector2(205, size.y - 198)
    btn_sprint.size = Vector2(117, 69)
    btn_jump.position = Vector2(size.x - 420, size.y - 278)
    btn_jump.size = Vector2(120, 68)
    btn_slide.position = Vector2(size.x - 285, size.y - 278)
    btn_slide.size = Vector2(120, 68)
    btn_vault.position = Vector2(size.x - 150, size.y - 278)
    btn_vault.size = Vector2(122, 68)
    end_screen.position = size * 0.5 - Vector2(220, 150)
    end_screen.size = Vector2(440, 310)

func _move_dot() -> void:
    if move_dot == null:
        return
    move_dot.position = move_circle.position + Vector2(76, 76) + joystick_axis * 49 - Vector2(25, 25)
    move_dot.size = Vector2(50, 50)

func _input(event: InputEvent) -> void:
    if ended:
        return
    var size := get_viewport().get_visible_rect().size
    if event is InputEventScreenTouch:
        if event.pressed:
            if event.position.x < size.x * 0.43 and event.position.y > size.y * 0.32 and joystick_touch == -1:
                joystick_touch = event.index
                joystick_origin = move_circle.position + Vector2(76, 76)
                joystick_axis = (event.position - joystick_origin).limit_length(68) / 68.0
                _move_dot()
            elif event.position.x >= size.x * 0.4 and event.position.y < size.y * 0.7 and look_touch == -1:
                look_touch = event.index
        else:
            if event.index == joystick_touch:
                joystick_touch = -1
                joystick_axis = Vector2.ZERO
                _move_dot()
            if event.index == look_touch:
                look_touch = -1
    elif event is InputEventScreenDrag:
        if event.index == joystick_touch:
            joystick_axis = (event.position - joystick_origin).limit_length(68) / 68.0
            _move_dot()
        elif event.index == look_touch:
            _look(event.relative * TOUCH_SENSITIVITY)
    elif event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        _look(event.relative * 0.0025)
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
        if not mouse_look and event.position.y < size.y * 0.72:
            Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
            mouse_look = true
        elif mouse_look:
            _attack()
    elif event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_ESCAPE:
            mouse_look = false
            Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
        elif event.keycode == KEY_J:
            _attack()
        elif event.keycode == KEY_K:
            _kick()
        elif event.keycode == KEY_SPACE:
            _jump()
        elif event.keycode == KEY_C:
            _slide()
        elif event.keycode == KEY_E:
            _vault()

func _look(delta: Vector2) -> void:
    player_yaw -= delta.x
    player_pitch = clamp(player_pitch - delta.y, -1.05, 1.05)
    player.rotation.y = player_yaw
    cam.rotation.x = player_pitch

func _physics_process(delta: float) -> void:
    if ended:
        return
    var axis := joystick_axis
    if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT): axis.x -= 1
    if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT): axis.x += 1
    if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP): axis.y -= 1
    if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN): axis.y += 1
    axis = axis.limit_length(1.0)
    var wish := player.global_basis.x * axis.x + player.global_basis.z * axis.y
    wish.y = 0.0
    var use_sprint := sprinting or Input.is_key_pressed(KEY_SHIFT)
    var actual_speed := SPRINT_SPEED if use_sprint and stamina > 0 else SPEED
    if use_sprint and axis.length_squared() > 0.1 and stamina > 0.0:
        stamina = maxf(0.0, stamina - 12.0 * delta)
    if slide_timer > 0.0:
        var speed_slide := lerpf(8.0, 12.0, slide_timer / SLIDE_DURATION)
        player.velocity.x = slide_vector.x * speed_slide
        player.velocity.z = slide_vector.z * speed_slide
    else:
        var mul := 3.1 if dodge_timer > 0.0 else 1.0
        player.velocity.x = wish.x * actual_speed * mul
        player.velocity.z = wish.z * actual_speed * mul
    if not player.is_on_floor():
        player.velocity.y -= 18.0 * delta
    elif player.velocity.y < 0.0:
        player.velocity.y = -0.2
    player.move_and_slide()
    # Slide uses a low camera and a short burst of momentum; it does not
    # reduce the collision capsule, so it cannot enter low ceiling gaps.
    var target_height := 1.03 if slide_timer > 0.0 else base_camera_height
    cam.position.y = lerpf(cam.position.y, target_height, minf(delta * 13.0, 1.0))
    player.position.x = clamp(player.position.x, -ARENA, ARENA)
    player.position.z = clamp(player.position.z, -ARENA, ARENA)

func _jump() -> void:
    if ended or not player.is_on_floor() or stamina < 7.0:
        return
    stamina -= 7.0
    player.velocity.y = JUMP_IMPULSE

func _slide() -> void:
    if ended or not player.is_on_floor() or slide_cooldown > 0.0 or stamina < 22.0:
        return
    stamina -= 22.0
    slide_timer = SLIDE_DURATION
    slide_cooldown = 1.2
    slide_vector = -player.global_basis.z
    slide_vector.y = 0.0
    slide_vector = slide_vector.normalized()

func _vault() -> void:
    if ended or not player.is_on_floor() or vault_cooldown > 0.0 or stamina < 16.0:
        return
    var direction := -player.global_basis.z
    direction.y = 0.0
    var from_pos := player.global_position + Vector3(0, 0.65, 0)
    var ray := PhysicsRayQueryParameters3D.create(from_pos, from_pos + direction * 1.65)
    ray.exclude = [player.get_rid()]
    var hit := player.get_world_3d().direct_space_state.intersect_ray(ray)
    if hit.is_empty():
        _announce("MOVE CLOSE TO A CRATE", 0.55)
        return
    # Assisted jump past a waist-high obstacle, without teleporting.
    stamina -= 16.0
    player.velocity.y = 8.4
    player.velocity.x += direction.x * 5.2
    player.velocity.z += direction.z * 5.2
    vault_cooldown = 1.0
    _announce("VAULT!", 0.5)

func _attack() -> void:
    if ended or punch_cooldown > 0 or wave_pause > 0:
        return
    punch_cooldown = 0.28
    punch_anim = 0.28
    punch_side = 1 - punch_side
    combo += 1
    snd_punch.play()
    _try_hit(1.0, 2.4, 0.57)

func _kick() -> void:
    if ended or punch_cooldown > 0 or wave_pause > 0:
        return
    punch_cooldown = 0.66
    punch_anim = 0.45
    snd_punch.play()
    _try_hit(2.0, 2.85, 0.42)

func _dodge() -> void:
    if ended or dash_cooldown > 0 or stamina < 28:
        return
    stamina -= 28
    dodge_timer = 0.20
    dash_cooldown = 1.25

func _try_hit(power: float, rng: float, aim: float) -> void:
    var nearest: Dictionary = {}
    var nearest_dist := 999.0
    for enemy in enemies:
        if not enemy["alive"]:
            continue
        var offset: Vector3 = enemy["node"].global_position - player.global_position
        offset.y = 0
        var d := offset.length()
        var forward := -cam.global_basis.z
        forward.y = 0
        if d < rng and d < nearest_dist and forward.normalized().dot(offset.normalized()) > aim:
            nearest = enemy
            nearest_dist = d
    if nearest.is_empty():
        combo = 0
        return
    nearest["hp"] -= power
    nearest["stun"] = 0.55 if power == 1.0 else 0.9
    var root: Node3D = nearest["node"]
    root.position += (root.global_position - player.global_position).normalized() * 0.27
    nearest["bar"].scale.x = max(0.05, nearest["hp"] / nearest["max_hp"])
    snd_hit.play()
    _blood(root.global_position + Vector3(0, 1.6, 0), 9 if power > 1 else 5)
    if nearest["hp"] <= 0:
        nearest["alive"] = false
        score += 100 + combo * 15
        root.visible = false
        _blood(root.global_position + Vector3(0, 1.1, 0), 18)

func _blood(pos: Vector3, amount: int) -> void:
    # Stylized short-lived crimson droplets; no gore textures / dismemberment.
    for i in range(amount):
        var drop := _sphere(self, pos, randf_range(0.035, 0.095), Color("db1643"), false)
        particles.append({"node": drop, "speed": Vector3(randf_range(-2, 2), randf_range(0.6, 3.0), randf_range(-2, 2)), "life": randf_range(0.45, 0.95)})
    var stain := _box(self, Vector3(pos.x, 0.04, pos.z), Vector3(randf_range(0.22, 0.65), 0.014, randf_range(0.15, 0.42)), Color("81162b"))
    stain.rotation.y = randf() * TAU
    particles.append({"node": stain, "speed": Vector3.ZERO, "life": 14.0})

func _finish(win: bool) -> void:
    if ended:
        return
    ended = true
    end_screen.visible = true
    var heading := "NIGHT CLEARED" if win else "YOU WENT DOWN"
    end_label.text = heading + "\n\nSCORE: " + str(score) + "\nCOMBO: " + str(combo) + "\n\n" + ("THE CITY IS YOURS." if win else "GET UP. FIGHT AGAIN.")
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    mouse_look = false

func _announce(text: String, seconds: float) -> void:
    if banner:
        banner.text = text
    round_timer = seconds

func _process(delta: float) -> void:
    if ended:
        return
    punch_cooldown = maxf(punch_cooldown - delta, 0.0)
    dash_cooldown = maxf(dash_cooldown - delta, 0.0)
    dodge_timer = maxf(dodge_timer - delta, 0.0)
    slide_timer = maxf(slide_timer - delta, 0.0)
    slide_cooldown = maxf(slide_cooldown - delta, 0.0)
    vault_cooldown = maxf(vault_cooldown - delta, 0.0)
    punch_anim = maxf(punch_anim - delta, 0.0)
    wave_pause = maxf(wave_pause - delta, 0.0)
    round_timer = maxf(round_timer - delta, 0.0)
    hurt_flash = maxf(hurt_flash - delta * 2.8, 0.0)
    tint.color = Color(0.95, 0.0, 0.12, hurt_flash * 0.28)
    if banner:
        banner.visible = round_timer > 0
    stamina = minf(100.0, stamina + 17.0 * delta)
    var jab := sin((0.28 - punch_anim) / 0.28 * PI) * 0.34 if punch_anim > 0 else 0.0
    left_arm.position.z = -0.72 - (jab if punch_side == 0 else 0.0)
    right_arm.position.z = -0.72 - (jab if punch_side == 1 else 0.0)
    left_arm.position.y = -0.48 + (0.12 if blocking else 0.0)
    right_arm.position.y = -0.48 + (0.12 if blocking else 0.0)
    _tick_enemies(delta)
    _tick_particles(delta)
    hud_left.text = "FIRST BLOOD  //  HP %03d   STAMINA %03d" % [int(health), int(stamina)]
    hud_right.text = "ROUND %d/3  |  SCORE %d" % [maxi(1, wave), score]
    if wave == 0 and wave_pause <= 0:
        _new_wave()
    elif wave > 0 and wave_pause <= 0:
        var left := 0
        for e in enemies:
            if e["alive"]:
                left += 1
        if left == 0:
            _new_wave()

func _tick_enemies(delta: float) -> void:
    if wave_pause > 0:
        return
    for e in enemies:
        if not e["alive"]:
            continue
        var node: Node3D = e["node"]
        e["cooldown"] -= delta
        e["stun"] = maxf(0.0, e["stun"] - delta)
        var to_player: Vector3 = player.global_position - node.global_position
        to_player.y = 0
        var dist := to_player.length()
        if dist > 0.05:
            node.rotation.y = atan2(-to_player.x, -to_player.z)
        if e["stun"] > 0:
            continue
        if dist > 1.45 and dist < 25.0:
            node.position += to_player.normalized() * float(e["speed"]) * delta
        var wobble := sin(Time.get_ticks_msec() * 0.007 + float(e["stride"])) * 0.20
        e["left"].rotation.x = wobble
        e["right"].rotation.x = -wobble
        if dist < 1.85 and e["cooldown"] <= 0:
            e["cooldown"] = randf_range(1.0, 1.75) if not e["boss"] else 0.82
            _hurt_player(22.0 if e["boss"] else 12.0)

func _hurt_player(damage: float) -> void:
    if dodge_timer > 0:
        return
    if blocking:
        if stamina > 6:
            stamina = maxf(0, stamina - 9)
            _announce("BLOCKED", 0.35)
            return
    health = maxf(0.0, health - damage)
    hurt_flash = 0.85
    snd_damage.play()
    combo = 0
    if health <= 0:
        _finish(false)

func _tick_particles(delta: float) -> void:
    for i in range(particles.size() - 1, -1, -1):
        var p: Dictionary = particles[i]
        p["life"] -= delta
        if p["life"] <= 0:
            p["node"].queue_free()
            particles.remove_at(i)
        else:
            if p["speed"].length_squared() > 0:
                p["speed"].y -= 11.0 * delta
                p["node"].position += p["speed"] * delta
                if p["node"].position.y < 0.04:
                    p["node"].position.y = 0.04
                    p["speed"] = Vector3.ZERO
